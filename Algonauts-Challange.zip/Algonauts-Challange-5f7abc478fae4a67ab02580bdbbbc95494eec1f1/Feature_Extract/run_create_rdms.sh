python create_RDMs.py -fd './feats/92images_feats/' -sd './rdms/92images_rdms/' -d pearson --net all
