CUDA_VISIBLE_DEVICES=0 python generate_features.py -id '/home/user/Git/VisualBrain/algonautsChallenge2019/Training_Data/92_Image_Set/92images' -sd './feats' --net all
